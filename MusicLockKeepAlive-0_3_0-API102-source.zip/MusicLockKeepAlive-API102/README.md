# MusicLockKeepAlive 0.3.0（libxposed API 102）

目标设备：OnePlus 15 PLK110 / ColorOS 17.0.0.102 CN01
框架 API：libxposed API 102.0.0　开发语言：Java 17

## 行为
锁屏 + 屏幕已亮 + 任一媒体会话处于 PLAYING 时保持常亮；
暂停、解锁、息屏、手动按电源键，或连续常亮超过 30 分钟，都会释放。
不修改系统息屏时间，不会点亮已熄灭的屏幕。

## 0.3.0 相对 0.2.0 的改动
- **主方案改为 SystemUI 进程内持有 SCREEN_BRIGHT WakeLock**：
  不再依赖 ColorOS 的 View 类名；歌词界面无论由 SystemUI 绘制，还是音乐 App 的
  showWhenLocked Activity，都能生效。带 15 秒超时并每 2 秒续期，SystemUI 异常时自动释放。
- 窗口 `keepScreenOn` 降级为兜底（WakeLock 被拒时启用），且只还原自己改过的 View，
  不再覆盖 SystemUI 原有设置。
- 事件驱动：监听亮/灭屏广播、活动会话变化、每个会话的播放状态回调；
  亮屏时 2 秒保险轮询，息屏后停止轮询。
- 暂停/切歌 5 秒缓冲，切歌瞬间不会闪断。
- 连续常亮上限 30 分钟（防口袋里一直亮、OLED 烧屏）。
- 息屏广播到达时先放锁，避免进入 AOD 时被 WakeLock 顶亮。
- 入口优先使用清单声明的 Application 类，并沿父类链找 `onCreate`；增加 `isFirstPackage()` 判断。
- `module.prop` 移除了在 API 102 文档里无法确认的 `autoHotReload`。
- 新增 `gradle/wrapper/gradle-wrapper.properties`（Gradle 8.9，满足 AGP 8.6.1）。

## 构建
1. Android Studio 打开项目根目录，JDK 17，安装 Android SDK Platform 35。
2. Gradle Sync 后执行 `assembleDebug`。
3. 输出：`app/build/outputs/apk/debug/app-debug.apk`。

## 使用与验证
1. 安装 APK，在 LSPosed（需支持 API 102）中启用，作用域 SystemUI，重启 SystemUI 或手机。
2. 播放音乐并锁屏、点亮屏幕，抓日志：
   `adb logcat -s MusicLockKeepAlive`
   看到 `keepScreenOn=true (wakelock)` 即生效。
3. 确认系统层面确实持有了锁：
   `adb shell dumpsys power | grep MusicLockKeepAlive`
4. 若出现 `WakeLock denied, switch to window-flag fallback`，说明走了兜底方案，请把日志发出来。

## 适配歌词界面（可选）
`KeepAliveMonitor` 顶部的参数可调：
- `DEBUG_DUMP = true`：锁屏播放 3 秒后，把名称含 lyric/lrc/music/media/player 的可见 View
  打到 logcat（`=== view dump begin ===` 之间）。
- 想让“只在真正显示歌词时才常亮”：根据 dump 结果修改 `LYRIC_KEYWORDS`，
  再把 `REQUIRE_LYRIC_VIEW` 设为 true。
  注意：如果歌词是音乐 App 自己的 Activity，SystemUI 窗口里找不到，不要开这一项。
- `MAX_CONTINUOUS_MS`、`PAUSE_GRACE_MS`、`IGNORED_PACKAGES` 分别控制上限、缓冲和排除的播放器。

## 已知限制
- 未在真机上编译或验证；构建环境没有 SDK，只做了人工的 API 签名复核。
- 本模块无法判断手机是否在口袋里；锁屏亮屏播放时会一直亮到暂停/解锁/30 分钟上限。
