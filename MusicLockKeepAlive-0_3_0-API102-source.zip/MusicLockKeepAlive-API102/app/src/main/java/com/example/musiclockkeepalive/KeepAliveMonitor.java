package com.example.musiclockkeepalive;

import android.app.Application;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * 锁屏 + 亮屏 + 有媒体会话在播放 时，保持屏幕常亮。
 *
 * 主方案：在 SystemUI 进程里持有 SCREEN_BRIGHT WakeLock。
 *   - 不依赖 ColorOS 的 View 类名；
 *   - 歌词界面无论是 SystemUI 自绘，还是音乐 App 的 showWhenLocked Activity 都有效；
 *   - 带超时，每个周期续期，SystemUI 异常时最多 WAKELOCK_TIMEOUT_MS 后自动释放。
 * 兜底方案：WakeLock 被拒绝时，对 SystemUI 窗口根 View 设置 keepScreenOn。
 *
 * 所有逻辑都在主线程 Handler 上执行。
 */
final class KeepAliveMonitor {
    private static final String TAG = "MusicLockKeepAlive";

    // ================= 可调参数 =================
    /** 亮屏期间的轮询间隔（事件驱动之外的保险）。 */
    private static final long TICK_MS = 2000L;
    /** WakeLock 单次持有时长；每个 tick 续期。 */
    private static final long WAKELOCK_TIMEOUT_MS = 15_000L;
    /** 暂停/切歌缓冲：最后一次检测到 PLAYING 之后仍视为“在播放”的时长。 */
    private static final long PAUSE_GRACE_MS = 5_000L;
    /** 单次连续常亮上限，防止口袋里一直亮 / OLED 烧屏。0 表示不限制。 */
    private static final long MAX_CONTINUOUS_MS = 30L * 60L * 1000L;
    /** 为 true 时，只有在 SystemUI 窗口里发现可见的“歌词”View 才常亮（需按日志调关键字）。 */
    private static final boolean REQUIRE_LYRIC_VIEW = false;
    private static final String[] LYRIC_KEYWORDS = {"lyric", "lrc"};
    /** 锁屏+播放开始时把相关 View 打到 logcat，用于适配 ColorOS。稳定后可改为 false。 */
    private static final boolean DEBUG_DUMP = true;
    private static final String[] DUMP_KEYWORDS =
        {"lyric", "lrc", "music", "media", "player", "song"};
    private static final int DUMP_MAX_LINES = 120;
    private static final int TREE_MAX_NODES = 5000;
    private static final int TREE_MAX_DEPTH = 40;
    /** 不参与判断的播放器包名（例如不想让某个 App 触发常亮）。 */
    private static final Set<String> IGNORED_PACKAGES = new HashSet<>();

    // ================= 状态 =================
    private static Application app;
    private static Handler handler;
    private static PowerManager powerManager;
    private static KeyguardManager keyguardManager;
    private static MediaSessionManager sessionManager;
    private static PowerManager.WakeLock wakeLock;

    private static boolean receiverOk;
    private static boolean sessionListenerOk;
    private static boolean lastInteractive;
    private static boolean everPlayed;
    private static long lastPlayingAt;
    private static boolean prevBase;
    private static boolean held;
    private static long holdStart;
    private static boolean capped;
    private static boolean useWindowFlagFallback;
    private static boolean sessionDeniedLogged;
    private static boolean rootViewsWarned;

    private static final List<MediaController> watched = new ArrayList<>();
    private static final List<MediaController.Callback> watchedCallbacks = new ArrayList<>();
    private static final Set<View> flagged =
        Collections.newSetFromMap(new WeakHashMap<View, Boolean>());

    private static Object wmgInstance;
    private static Field viewsField;

    private KeepAliveMonitor() {}

    // ================= 入口 =================
    static synchronized void start(Application application) {
        if (handler != null) return;

        app = application;
        handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    init();
                } catch (Throwable t) {
                    Log.e(TAG, "init failed", t);
                }
            }
        });
    }

    @SuppressWarnings("deprecation")
    private static void init() {
        powerManager = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
        keyguardManager = (KeyguardManager) app.getSystemService(Context.KEYGUARD_SERVICE);
        sessionManager = (MediaSessionManager) app.getSystemService(Context.MEDIA_SESSION_SERVICE);
        if (powerManager == null || keyguardManager == null || sessionManager == null) {
            Log.e(TAG, "system service missing, abort");
            return;
        }

        wakeLock = powerManager.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK, TAG + ":lyrics");
        wakeLock.setReferenceCounted(false);

        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_USER_PRESENT);
            app.registerReceiver(RECEIVER, filter, null, handler);
            receiverOk = true;
        } catch (Throwable t) {
            Log.w(TAG, "registerReceiver failed, fall back to polling", t);
        }

        try {
            sessionManager.addOnActiveSessionsChangedListener(SESSIONS_LISTENER, null, handler);
            sessionListenerOk = true;
        } catch (Throwable t) {
            Log.w(TAG, "session listener failed, fall back to polling", t);
        }

        Log.i(TAG, "monitor started (receiver=" + receiverOk
            + ", sessionListener=" + sessionListenerOk + ")");
        evaluate();
    }

    // ================= 事件源 =================
    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            evaluate();
        }
    };

    private static final BroadcastReceiver RECEIVER = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent == null ? null : intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                // 先放锁，避免息屏/进入 AOD 时被 WakeLock 顶亮。
                setHeld(false);
            }
            evaluate();
        }
    };

    private static final MediaSessionManager.OnActiveSessionsChangedListener SESSIONS_LISTENER =
        new MediaSessionManager.OnActiveSessionsChangedListener() {
            @Override
            public void onActiveSessionsChanged(List<MediaController> controllers) {
                evaluate();
            }
        };

    private static final class SessionCallback extends MediaController.Callback {
        @Override
        public void onPlaybackStateChanged(PlaybackState state) {
            evaluate();
        }

        @Override
        public void onSessionDestroyed() {
            evaluate();
        }
    }

    // ================= 核心判断 =================
    private static void evaluate() {
        if (handler == null || powerManager == null) return;
        handler.removeCallbacks(TICK);
        try {
            doEvaluate();
        } catch (Throwable t) {
            Log.e(TAG, "evaluate failed", t);
            try {
                setHeld(false);
            } catch (Throwable ignored) {
                // 保持静默：此处只求不要把锁留着。
            }
        } finally {
            if (lastInteractive) {
                handler.postDelayed(TICK, TICK_MS);
            } else if (!receiverOk) {
                handler.postDelayed(TICK, 5000L); // 没有广播可依赖时，息屏后慢速轮询。
            }
        }
    }

    private static void doEvaluate() {
        long now = SystemClock.uptimeMillis();
        boolean interactive = powerManager.isInteractive();
        lastInteractive = interactive;
        boolean locked = keyguardManager.isKeyguardLocked();

        List<MediaController> sessions = querySessions();
        syncCallbacks(sessions);
        if (anyPlaying(sessions)) {
            lastPlayingAt = now;
            everPlayed = true;
        }
        boolean musicActive = everPlayed && (now - lastPlayingAt) <= PAUSE_GRACE_MS;

        boolean base = interactive && locked && musicActive;
        if (base && !prevBase && DEBUG_DUMP) {
            handler.postDelayed(DUMP, 3000L); // 等歌词界面绘制出来再 dump。
        }
        prevBase = base;

        boolean want = base && (!REQUIRE_LYRIC_VIEW || hasVisibleLyricView());

        if (!want) {
            holdStart = 0L;
            capped = false;
        } else if (holdStart == 0L) {
            holdStart = now;
        } else if (!capped && MAX_CONTINUOUS_MS > 0 && now - holdStart >= MAX_CONTINUOUS_MS) {
            capped = true;
            Log.i(TAG, "reached MAX_CONTINUOUS_MS, release until state changes");
        }

        setHeld(want && !capped);
    }

    // ================= 媒体会话 =================
    private static List<MediaController> querySessions() {
        try {
            List<MediaController> list = sessionManager.getActiveSessions(null);
            return list == null ? Collections.<MediaController>emptyList() : list;
        } catch (SecurityException e) {
            if (!sessionDeniedLogged) {
                sessionDeniedLogged = true;
                Log.w(TAG, "Cannot read active media sessions", e);
            }
        } catch (Throwable t) {
            Log.w(TAG, "Media session query failed", t);
        }
        return Collections.emptyList();
    }

    private static boolean anyPlaying(List<MediaController> sessions) {
        for (MediaController c : sessions) {
            if (c == null) continue;
            if (IGNORED_PACKAGES.contains(c.getPackageName())) continue;
            PlaybackState s = c.getPlaybackState();
            if (s != null && s.getState() == PlaybackState.STATE_PLAYING) return true;
        }
        return false;
    }

    /** 会话集合变化时，重新给每个 controller 挂播放状态回调（每个 controller 一个独立回调实例）。 */
    private static void syncCallbacks(List<MediaController> sessions) {
        if (sameSessions(watched, sessions)) return;

        for (int i = 0; i < watched.size(); i++) {
            try {
                watched.get(i).unregisterCallback(watchedCallbacks.get(i));
            } catch (Throwable ignored) {
                // controller 可能已失效。
            }
        }
        watched.clear();
        watchedCallbacks.clear();

        for (MediaController c : sessions) {
            if (c == null) continue;
            SessionCallback cb = new SessionCallback();
            try {
                c.registerCallback(cb, handler);
                watched.add(c);
                watchedCallbacks.add(cb);
            } catch (Throwable t) {
                Log.w(TAG, "registerCallback failed for " + c.getPackageName(), t);
            }
        }
    }

    private static boolean sameSessions(List<MediaController> a, List<MediaController> b) {
        int bCount = 0;
        for (MediaController c : b) if (c != null) bCount++;
        if (a.size() != bCount) return false;
        for (MediaController c : b) {
            if (c == null) continue;
            boolean found = false;
            for (MediaController w : a) {
                if (w.getSessionToken().equals(c.getSessionToken())) {
                    found = true;
                    break;
                }
            }
            if (!found) return false;
        }
        return true;
    }

    // ================= 持有 / 释放 =================
    private static void setHeld(boolean hold) {
        if (wakeLock == null) return;
        try {
            if (hold) {
                if (useWindowFlagFallback) {
                    applyWindowFlag(true);
                } else {
                    wakeLock.acquire(WAKELOCK_TIMEOUT_MS); // 非计数锁，重复 acquire 即续期。
                }
            } else {
                if (wakeLock.isHeld()) wakeLock.release();
                if (!flagged.isEmpty()) applyWindowFlag(false);
            }
        } catch (SecurityException e) {
            Log.w(TAG, "WakeLock denied, switch to window-flag fallback", e);
            useWindowFlagFallback = true;
            if (hold) applyWindowFlag(true);
        } catch (Throwable t) {
            Log.w(TAG, "setHeld failed", t);
        }

        if (hold != held) {
            held = hold;
            Log.i(TAG, "keepScreenOn=" + hold
                + (useWindowFlagFallback ? " (window flag)" : " (wakelock)"));
        }
    }

    // ================= 兜底：窗口标志 =================
    private static void applyWindowFlag(boolean enabled) {
        if (enabled) {
            for (View v : getRootViews()) {
                if (!isLockscreenRoot(v)) continue;
                if (!v.getKeepScreenOn()) { // 只改我们自己动过的，避免覆盖 SystemUI 原有设置。
                    v.setKeepScreenOn(true);
                    flagged.add(v);
                }
            }
        } else {
            for (View v : new ArrayList<>(flagged)) {
                v.setKeepScreenOn(false);
            }
            flagged.clear();
        }
    }

    private static boolean isLockscreenRoot(View v) {
        String n = v.getClass().getName();
        return n.contains("NotificationShadeWindowView")
            || n.contains("StatusBarWindowView")
            || n.contains("Keyguard");
    }

    private static List<View> getRootViews() {
        try {
            if (viewsField == null) {
                Class<?> c = Class.forName("android.view.WindowManagerGlobal");
                wmgInstance = c.getMethod("getInstance").invoke(null);
                Field f = c.getDeclaredField("mViews");
                f.setAccessible(true);
                viewsField = f;
            }
            Object o = viewsField.get(wmgInstance);
            if (o instanceof List<?>) {
                List<View> out = new ArrayList<>();
                for (Object item : (List<?>) o) {
                    if (item instanceof View) out.add((View) item);
                }
                return out;
            }
        } catch (Throwable t) {
            if (!rootViewsWarned) {
                rootViewsWarned = true;
                Log.w(TAG, "Cannot read WindowManagerGlobal.mViews", t);
            }
        }
        return Collections.emptyList();
    }

    // ================= 歌词 View 识别 / 调试 dump =================
    private static boolean hasVisibleLyricView() {
        int[] budget = {TREE_MAX_NODES};
        for (View root : getRootViews()) {
            if (findLyric(root, 0, budget)) return true;
            if (budget[0] <= 0) break;
        }
        return false;
    }

    private static boolean findLyric(View v, int depth, int[] budget) {
        if (v == null || depth > TREE_MAX_DEPTH || budget[0]-- <= 0) return false;
        if (v.getVisibility() != View.VISIBLE) return false;
        if (matches(v.getClass().getName(), idName(v), LYRIC_KEYWORDS) && v.isShown()) {
            return true;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                if (findLyric(g.getChildAt(i), depth + 1, budget)) return true;
            }
        }
        return false;
    }

    private static final Runnable DUMP = new Runnable() {
        @Override
        public void run() {
            if (!prevBase) return; // 3 秒后状态已变化则不再 dump。
            try {
                int[] lines = {0};
                int[] budget = {TREE_MAX_NODES};
                Log.i(TAG, "=== view dump begin ===");
                for (View root : getRootViews()) {
                    Log.i(TAG, "root " + root.getClass().getName() + " shown=" + root.isShown());
                    dumpTree(root, 0, lines, budget);
                }
                Log.i(TAG, "=== view dump end (" + lines[0] + " matched lines) ===");
            } catch (Throwable t) {
                Log.w(TAG, "dump failed", t);
            }
        }
    };

    private static void dumpTree(View v, int depth, int[] lines, int[] budget) {
        if (v == null || depth > TREE_MAX_DEPTH || budget[0]-- <= 0
            || lines[0] >= DUMP_MAX_LINES) return;
        if (v.getVisibility() != View.VISIBLE) return;

        String cn = v.getClass().getName();
        String idn = idName(v);
        if (matches(cn, idn, DUMP_KEYWORDS)) {
            lines[0]++;
            Log.i(TAG, "d=" + depth + " " + cn + " id=" + idn + " shown=" + v.isShown());
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                dumpTree(g.getChildAt(i), depth + 1, lines, budget);
            }
        }
    }

    private static String idName(View v) {
        int id = v.getId();
        if (id == View.NO_ID) return "";
        try {
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return "";
        }
    }

    private static boolean matches(String className, String idName, String[] keywords) {
        String c = className.toLowerCase(Locale.ROOT);
        String i = idName.toLowerCase(Locale.ROOT);
        for (String k : keywords) {
            if (c.contains(k) || i.contains(k)) return true;
        }
        return false;
    }
}
