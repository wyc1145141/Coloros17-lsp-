package com.example.musiclockkeepalive;

import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.util.Log;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface.PackageReadyParam;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * libxposed API 102 entry.
 * 仅在 SystemUI 主进程里 hook Application.onCreate，拿到 Application 后启动监控。
 */
public final class MusicLockKeepAlive extends XposedModule {
    private static final String TAG = "MusicLockKeepAlive";
    private static final String SYSTEM_UI = "com.android.systemui";
    private static final String FALLBACK_APP_CLASS = "com.android.systemui.SystemUIApplication";

    @Override
    public void onPackageReady(PackageReadyParam param) {
        if (!SYSTEM_UI.equals(param.getPackageName()) || !param.isFirstPackage()) {
            return;
        }

        try {
            Method onCreate = findAppOnCreate(param.getClassLoader(), param.getApplicationInfo());

            hook(onCreate)
                .setId("musiclockkeepalive_systemui_app_oncreate")
                .intercept(chain -> {
                    Object result = chain.proceed();
                    Object receiver = chain.getThisObject();

                    if (receiver instanceof Application) {
                        KeepAliveMonitor.start((Application) receiver);
                    } else {
                        log(Log.WARN, TAG, "onCreate receiver is not an Application");
                    }
                    return result;
                });

            log(Log.INFO, TAG, "hook installed on "
                + onCreate.getDeclaringClass().getName() + ".onCreate, apiVersion="
                + getApiVersion());
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to install SystemUI hook", t);
        }
    }

    /**
     * 优先使用清单里声明的 Application 类（ColorOS 可能用子类），
     * 沿父类链找到真正声明了 onCreate() 的那一层。
     */
    private static Method findAppOnCreate(ClassLoader cl, ApplicationInfo info)
        throws NoSuchMethodException {
        List<String> names = new ArrayList<>();
        if (info != null && info.className != null) names.add(info.className);
        names.add(FALLBACK_APP_CLASS);

        for (String name : names) {
            try {
                Class<?> c = cl.loadClass(name);
                while (c != null && c != Object.class) {
                    try {
                        return c.getDeclaredMethod("onCreate");
                    } catch (NoSuchMethodException e) {
                        c = c.getSuperclass();
                    }
                }
            } catch (ClassNotFoundException ignored) {
                // 试下一个候选类名。
            }
        }
        return Application.class.getDeclaredMethod("onCreate");
    }
}
